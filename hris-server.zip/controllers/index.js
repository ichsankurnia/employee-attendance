const AdminController = require('./controller-admin');
const EmployeeController = require('./controller-employee');
const AttendanceController = require('./controller-attendance');

module.exports = {
  AdminController,
  EmployeeController,
  AttendanceController
};
