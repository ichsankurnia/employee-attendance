const errorHandler = require('./errorHandler');
const isAuthenticated = require('./auth');

module.exports = {
  errorHandler,
  isAuthenticated
};
